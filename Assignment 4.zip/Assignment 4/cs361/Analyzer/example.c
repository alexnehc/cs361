#include <stdio.h>
#include <stdlib.h>

int main() {
    int a;
    printf("Enter whole number:\n");
    scanf("%d", &a);

    if (a % 2 == 0)
        printf("c is even.\n");
    else
        printf("c is odd.\n");
    return 0;
}